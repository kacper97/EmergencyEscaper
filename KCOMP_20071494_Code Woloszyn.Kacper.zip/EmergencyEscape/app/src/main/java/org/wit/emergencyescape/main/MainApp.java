package org.wit.emergencyescape.main;
import android.app.Application;

public class MainApp extends Application
{
    //public List <LocationModel>  locations = new ArrayList<>();
    //starting the app
    @Override
    public void onCreate()
    {
        super.onCreate();
    }
}